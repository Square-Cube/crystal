<?php $__env->startSection('title'); ?>
    All users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">users</div>
            <div class="widget-content">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="custom-btn">add user</a>
                <div class="spacer-15"></div>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6">
                        <li class="employ-item">
                            <img src="<?php echo e(asset('storage/uploads/users/'.$user->image)); ?>">
                            <div class="employ-info">
                                <a class="title" href="<?php echo e(route('admin.users.single',['id' => $user->id])); ?>"><?php echo e($user->username); ?></a>
                                <div class="work-place">
                                    <i class="fa fa-map-marker"></i>
                                    <?php echo e($user->address); ?>

                                </div>
                                <div class="type">
                                    <i class="fa fa-user"></i>
                                    <?php echo e($user->type); ?>

                                </div>
                            </div>
                        </li>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>