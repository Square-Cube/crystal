<?php $__env->startSection('title'); ?>
    Add project
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">add project</div>
            <div class="widget-content">
                <form class="add-user" action="<?php echo e(route('admin.projects.add')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="alert alert-success hidden SuccessMessage" id=""></div>
                    <div class="alert alert-danger hidden ErrorMessage" id=""></div>

                    <input type="hidden" name="lng">
                    <input type="hidden" name="lat">

                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label>project name</label>
                            <input class="form-control" placeholder="" name="project_name" type="text">
                        </div>
                        <div class="form-group">
                            <label>address : </label>
                            <input class="form-control" type="text" id="geocomplete" placeholder="" name="address">
                        </div>
                        <div class="form-group">
                            <label>promoters : </label>
                            <select multiple class="tags form-control" name="promoters[]">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->username); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>about : </label>
                            <textarea class="form-control" placeholder="" name="about"></textarea>
                        </div>
                        <div class="form-group">
                            <label>project start date</label>
                            <div class="input-group date form_date" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                <input class="form-control" size="16" name="start_date" type="text" value="" >
                                <span class="input-group-addon">
                                    <span class="fa fa-calendar"></span>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>project end date : </label>
                            <div class="input-group date form_date" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                <input class="form-control" size="16" name="end_date" type="text" value="" >
                                <span class="input-group-addon">
                                    <span class="fa fa-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="form-group">
                            <label>project logo</label>
                            <input type="file" name="logo">
                        </div>
                        <div class="form-group">
                            <label>project locations</label>
                            <div class="map_canvas"></div>
                            
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <div class="form-group">
                            <button class="custom-btn submitBTN">add project</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyAABrilV0K0SLv21ZVMv8Inz5YMI4YAKbI&amp;libraries=places"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.geocomplete.min.js')); ?>"></script>

    <script>
        $("#geocomplete").geocomplete({
            map: ".map_canvas",
            details: "form ",
            markerOptions: {
                draggable: true
            }
        });
        $("#geocomplete").bind("geocode:dragged", function(event, latLng){
            $("input[name=lat]").val(latLng.lat());
            $("input[name=lng]").val(latLng.lng());
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>