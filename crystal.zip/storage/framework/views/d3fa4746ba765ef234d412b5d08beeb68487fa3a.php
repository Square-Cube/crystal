<?php $__env->startSection('title'); ?>
    Home page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div id="welcome-home">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12 wel-cont">
                        <div class="logo">
                            <img src="<?php echo e(asset('assets/admin/images/logo.png')); ?>">
                        </div>
                        <div class="mess">
                            <span>crystal</span><span> store</span><span> management</span>
                        </div>
                        <a href="<?php echo e(route('admin.login')); ?>" class="custom-btn">
                            sign in <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>