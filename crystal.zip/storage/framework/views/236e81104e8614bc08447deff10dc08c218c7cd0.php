<?php $__env->startSection('title'); ?>
User details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('models'); ?>
    <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="view-qust<?php echo e($questionnaire->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form class="modal-content text-center">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Questionnaire</h5>
                    </div>
                    <ul class="quest-cont">
                        <li>
                            Overall , How Would You Rate Crystal
                            <span><?php echo e($questionnaire->rate); ?></span>
                        </li>
                        <li>
                            Would You Recommend Crystal To A Friend
                            <span><?php echo e($questionnaire->recommend); ?></span>
                        </li>
                        <li>
                            Where Did You First Learn About Crystal
                            <span><?php echo e($questionnaire->learn); ?></span>
                        </li>
                    </ul>
                    <div class="modal-footer text-center">
                        <button type="button" class="custom-btn green-bc" data-dismiss="modal">close</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">user survay</div>
            <div class="widget-content only-user">
                <div class="col-sm-12">
                    <div class="user-inner-head">
                        <div class="user-inner-img">
                            <img src="<?php echo e(asset('storage/uploads/users/'.$user->image)); ?>">
                        </div>
                        <div class="info"> user name : <span> <?php echo e($user->username); ?> </span></div>
                        <div class="info"> user type : <span> <?php echo e($user->type); ?> </span></div>
                    </div>
                </div>
                <div class="col-sm-12">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab1" data-toggle="tab">Interaction</a></li>
                        <li><a href="#tab2" data-toggle="tab">Questionnaire</a></li>
                        <li><a href="#tab3" data-toggle="tab">products</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab1">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover text-center">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>name</th>
                                            <th>email</th>
                                            <th>number</th>
                                            <th>comment</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $interactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $interaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index+1); ?></td>
                                            <td><?php echo e($interaction->name); ?></td>
                                            <td><?php echo e($interaction->email); ?></td>
                                            <td><?php echo e($interaction->number); ?></td>
                                            <td>
                                                <?php echo e($interaction->comment); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade in" id="tab2">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover text-center">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>name</th>
                                        <th>number</th>
                                        <th>email</th>
                                        <th>Questionnaire</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index+1); ?></td>
                                                <td><?php echo e($questionnaire->name); ?></td>
                                                <td><?php echo e($questionnaire->phone); ?></td>
                                                <td><?php echo e($questionnaire->email); ?></td>
                                                <td>
                                                    <button data-toggle="modal" data-target="#view-qust<?php echo e($questionnaire->id); ?>" class="custom-btn">view</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade in" id="tab3">
                            <div class="user-surv-prod">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <div class="prod-item">
                                            <img src="<?php echo e(asset('storage/uploads/products/'.$product->image)); ?>">
                                            <div class="prod-count">product number <span><?php echo e($product->number); ?></span></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>