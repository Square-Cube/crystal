<div class="side-menu">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo">
        <?php if($project != null): ?>
            <img src="<?php echo e(asset('storage/uploads/projects/'.$project->logo)); ?>">
            <?php else: ?>
            <img src="<?php echo e(asset('assets/admin/images/logo.png')); ?>">
        <?php endif; ?>
    </a><!--End Logo-->
    <aside class="sidebar">
        <ul class="side-menu-links">
            <li class="<?php if(Request::route()->getName() == 'admin.dashboard'): ?><?php echo e('active'); ?><?php endif; ?>">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <img src="<?php echo e(asset('assets/admin/images/dashboard.png')); ?>">
                    dashboard
                </a>
            </li>
            <?php if(auth()->guard('admins')->user()->type == 'promoter' && $project != null): ?>
                <li class="<?php if(Request::route()->getName() == 'admin.interaction'): ?><?php echo e('active'); ?><?php endif; ?>">
                    <a href="<?php echo e(route('admin.interaction')); ?>">
                        <img src="<?php echo e(asset('assets/admin/images/icon1.png')); ?>">
                        interaction
                    </a>
                </li>
                <li class="<?php if(Request::route()->getName() == 'admin.questionnaire'): ?><?php echo e('active'); ?><?php endif; ?>">
                    <a href="<?php echo e(route('admin.questionnaire')); ?>">
                        <img src="<?php echo e(asset('assets/admin/images/icon2.png')); ?>">
                        questionnaire
                    </a>
                </li>
                <li class="<?php if(Request::route()->getName() == 'admin.products'): ?><?php echo e('active'); ?><?php endif; ?>">
                    <a href="<?php echo e(route('admin.products')); ?>">
                        <img src="<?php echo e(asset('assets/admin/images/icon3.png')); ?>">
                        products
                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->guard('admins')->user()->type == 'admin'): ?>
                <li class="<?php if(Request::route()->getName() == 'admin.projects'): ?><?php echo e('active'); ?><?php endif; ?>">
                    <a href="<?php echo e(route('admin.projects')); ?>">
                        <img src="<?php echo e(asset('assets/admin/images/projects.png')); ?>">
                        projects
                    </a>
                </li>
                <li class="<?php if(Request::route()->getName() == 'admin.users'): ?><?php echo e('active'); ?><?php endif; ?>">
                    <a href="<?php echo e(route('admin.users')); ?>">
                        <img src="<?php echo e(asset('assets/admin/images/users.png')); ?>">
                        users
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.notifications')); ?>">
                        <img src="<?php echo e(asset('assets/admin/images/send_notifications.png')); ?>">
                        send notifications
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </aside>
</div>