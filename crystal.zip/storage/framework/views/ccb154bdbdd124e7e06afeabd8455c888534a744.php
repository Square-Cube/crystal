<?php $__env->startSection('title'); ?>
    <?php echo e($user->username); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('models'); ?>
    <div class="modal fade" id="delete-user" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form class="modal-content text-center">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">do you want to delete user?</h5>
                </div>
                <div class="modal-footer text-center">
                    <a type="button" style="cursor: pointer;" class="custom-btn red-bc modalDLTBTN">delete</a>
                    <a type="button" style="cursor: pointer;" class="custom-btn green-bc" data-dismiss="modal">close</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="widget">
        <div class="widget-title"><?php echo e($user->username); ?></div>
        <div class="widget-content only-user">
            <div class="col-sm-12">
                <div class="title">
                    <div class="action">
                        <a href="<?php echo e(route('admin.users.edit' ,['id' => $user->id])); ?>" class="custom-btn">edit</a>
                        <button data-url="<?php echo e(route('admin.users.delete',['id' => $user->id])); ?>" data-toggle="modal" data-target="#delete-user" class="red-bc custom-btn deleteBTN">delete</button>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="user-inner-head">
                    <div class="user-inner-img">
                        <img src="<?php echo e(asset('storage/uploads/users/'.$user->image)); ?>">
                    </div>
                    <div class="info"> user name : <span> <?php echo e($user->username); ?> </span></div>
                    <div class="info"> user type : <span> <?php echo e($user->type); ?> </span></div>
                </div>
                <div class="col-sm-6"><div class="info"> User Phone Number : <span> <?php echo e($user->phone); ?> </span></div></div>
                <div class="col-sm-6"><div class="info"> User Address : <span> <?php echo e($user->address); ?> </span></div></div>
                <div class="col-sm-6"><div class="info"> User gender: <span> <?php echo e($user->gender); ?> </span></div></div>
                <div class="col-sm-6"><div class="info"> User Age : <span> <?php echo e($user->age); ?> </span></div></div>
                <div class="col-sm-6"><div class="info"> User Email Address : <span> <?php echo e($user->email); ?></span></div></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>