<?php $__env->startSection('title'); ?>
    notifications
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
        $allUsers = \App\User::where('type' , 'promoter')->get();
    ?>

    <?php if(request()->id): ?>
        <?php
            $user = \App\User::find(request()->id);
        ?>
    <?php endif; ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">send Notifications</div>
            <div class="widget-content">
                <form class="send-notfy-form">
                    <?php echo csrf_field(); ?>


                    <div class="alert alert-success hidden SuccessMessage" id=""></div>
                    <div class="alert alert-danger hidden ErrorMessage" id=""></div>

                    <div class="form-group">
                        <label>select user</label>
                        <select multiple  class="form-control tags" name="receiver_id[]">
                            <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($allUser->id); ?>" <?php if(request()->id): ?> <?php echo e($allUser->id == $user->id ? 'selected' : ' '); ?><?php endif; ?> ><?php echo e($allUser->username); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Messages</label>
                        <textarea class="form-control" placeholder="Messages" name="message"></textarea>
                    </div>
                    <div class="form-group">
                        <button class="custom-btn submitBTN">
                            send <i class="fa fa-angle-right"></i>
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>