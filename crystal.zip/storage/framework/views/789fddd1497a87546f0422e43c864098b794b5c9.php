<?php $__env->startSection('title'); ?>
    notifications
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">notifactions</div>
            <div class="widget-content">
                <ul class="inner-noty">
                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="notfy-item">
                            <?php echo e($notification->message); ?>

                            <div class="notfy-time">
                                <i class="fas fa-clock"></i>
                                <?php echo e($notification->created_at->diffForHumans()); ?>

                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>