<?php $__env->startSection('title'); ?>
    Projects
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">projects</div>
            <div class="widget-content">
                <a href="<?php echo e(route('admin.projects.add')); ?>" class="custom-btn">add project</a>
                <div class="spacer-15"></div>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6">
                        <div class="proj-item">
                            <div class="proj-item-img">
                                <img src="<?php echo e(asset('storage/uploads/projects/'.$singleProject->logo)); ?>">
                            </div>
                            <div class="proj-item-content">
                                <a class="title" href="<?php echo e(route('admin.projects.single',['id' => $singleProject->id])); ?>"><?php echo e($singleProject->name); ?></a>
                                <p>
                                    <?php echo e(str_limit($singleProject->about , 150)); ?>

                                </p>
                                <a href="<?php echo e(route('admin.projects.single',['id' => $singleProject->id])); ?>" class="custom-btn">
                                    more details
                                </a>
                                <a href="<?php echo e(route('admin.projects.edit',['id' => $singleProject->id])); ?>" class="custom-btn">
                                    edit project
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>