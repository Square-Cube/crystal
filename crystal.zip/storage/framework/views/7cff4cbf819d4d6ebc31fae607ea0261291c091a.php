<?php $__env->startSection('content'); ?>
    <?php
        $member = \App\User::where('id' , auth()->guard('admins')->user()->id)->first()
    ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">welcome to dashboard</div>
            <div class="widget-content">
                <div class="wel-cont">
                    <div class="profile-card">
                        <img src="<?php echo e(asset('storage/uploads/users/'.$member->image)); ?>">
                        <div class="profile-cont">
                            <ul>
                                <li><span>Your Name : </span> <?php echo e(auth()->guard('admins')->user()->username); ?></li>
                                <?php if(auth()->guard('admins')->user()->type == 'promoter'): ?>
                                    <li><span>Your Location : </span> <?php echo e($member->attendances()->latest()->value('location')); ?></li>
                                <?php endif; ?>
                                <li><span>Date : </span> <?php echo e(\Carbon\Carbon::parse($member->attendances()->latest()->value('time'))->format('d - m - Y')); ?></li>
                                <li><span>Time : </span> <?php echo e(\Carbon\Carbon::parse($member->attendances()->latest()->value('time'))->format('g:i A')); ?></li>
                            </ul>
                            <div class="action">
                                <?php if(auth()->guard('admins')->user()->type == 'promoter'): ?>
                                    <a data-url="<?php echo e(route('admin.breakout')); ?>" data-token="<?php echo csrf_token(); ?>" class="custom-btn BreakoutBTN" style="cursor: pointer;">Break</a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.logout')); ?>" class="custom-btn">logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>