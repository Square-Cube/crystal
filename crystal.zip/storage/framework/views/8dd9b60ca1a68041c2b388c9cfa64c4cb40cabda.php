<?php $__env->startSection('title'); ?>
    Edit users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title">edit user</div>
            <div class="widget-content">
                <form class="add-user" action="<?php echo e(route('admin.users.edit',['id' => $user->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="alert alert-success hidden SuccessMessage" id=""></div>
                    <div class="alert alert-danger hidden ErrorMessage" id=""></div>

                    <div class="col-sm-6 form-group">
                        <label>user name</label>
                        <input class="form-control" value="<?php echo e($user->username); ?>" name="username" type="text">
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user phone number</label>
                        <input class="form-control" value="<?php echo e($user->phone); ?>" name="phone" type="text">
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user address</label>
                        <input class="form-control" value="<?php echo e($user->address); ?>" name="address" type="text">
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user age</label>
                        <input class="form-control" value="<?php echo e($user->age); ?>" name="age" type="text">
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user type : </label>
                        <select class="form-control" name="type">
                            <option value="admin" <?php if($user->type == 'admin'): ?><?php echo e('selected'); ?><?php endif; ?>>admin</option>
                            <option value="promoter" <?php if($user->type == 'promoter'): ?><?php echo e('selected'); ?><?php endif; ?>>promoters</option>
                        </select>
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user Gender : </label>
                        <select class="form-control" name="gender">
                            <option value="male" <?php if($user->gender == 'male'): ?><?php echo e('selected'); ?><?php endif; ?>>male</option>
                            <option value="female" <?php if($user->gender == 'female'): ?><?php echo e('selected'); ?><?php endif; ?>>female</option>
                        </select>
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user Email address : </label>
                        <input class="form-control" type="email" value="<?php echo e($user->email); ?>" name="email">
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user password : </label>
                        <input class="form-control" type="password" name="password">
                    </div>
                    <div class="col-sm-6 form-group">
                        <label>user photo</label>
                        <input type="file" name="image">
                    </div>
                    <div class="col-sm-12 form-group">
                        <button class="custom-btn submitBTN">save change</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>