<?php $__env->startSection('title'); ?>
    <?php echo e($singleProject->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('models'); ?>
    <div class="modal fade" id="delete-user" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form class="modal-content text-center" action="<?php echo e(route('admin.projects.detach' ,['id' => $singleProject->id])); ?>" method="Get">
                <?php echo csrf_field(); ?>


                <input type="hidden" name="user_id" id="DetachUserId">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">do you want to delete project ?</h5>
                </div>
                <div class="modal-footer text-center">
                    <button type="submit" class="custom-btn red-bc ">delete</button>
                    <button type="submit" class="custom-btn green-bc" data-dismiss="modal">close</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal fade" id="delete-proj" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form class="modal-content text-center" >

                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">do you want to delete project ?</h5>
                </div>
                <div class="modal-footer text-center">
                    <a type="button" class="custom-btn red-bc modalDLTBTN">delete</a>
                    <a type="button" class="custom-btn green-bc" data-dismiss="modal">close</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="widget">
            <div class="widget-title"><?php echo e($singleProject->name); ?></div>
            <div class="widget-content only-project">
                <div class="col-md-12">
                    <div class="title">
                        <?php echo e($singleProject->name); ?>

                        <div class="action">
                            <a href="<?php echo e(route('admin.projects.edit',['id' => $singleProject->id])); ?>" class="custom-btn">edit</a>
                            <button data-toggle="modal" data-url="<?php echo e(route('admin.projects.delete',['id' => $singleProject->id])); ?>" data-target="#delete-proj" class="red-bc custom-btn deleteBTN">delete</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="details">
                        <div class="det-img">
                            <img src="<?php echo e(asset('storage/uploads/projects/'.$singleProject->logo)); ?>">
                        </div>
                        <div class="info">
                            <span>about : </span>
                            <?php echo e($singleProject->about); ?>

                        </div>
                        <div class="info">
                            <span>address : </span>
                            <?php echo e($singleProject->address); ?>

                        </div>
                        <div class="info">
                            <span>Promoters : <i>[ <?php echo e($singleProject->users->count()); ?> employees ]</i></span>
                            <?php $__currentLoopData = $singleProject->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="employ-item inline-employ">
                                    <img src="<?php echo e(asset('storage/uploads/users/'.$user->image)); ?>">
                                    <a href="<?php echo e(route('admin.users.details' ,['singleProduct' => $singleProject->id ,'user' => $user->id])); ?>"> <?php echo e($user->username); ?></a>
                                    <div class="action-btns">
                                        <a href="<?php echo e(route('admin.notifications',['id' => $user->id])); ?>" class="custom-btn">
                                            <i class="fa fa-envelope"></i>
                                        </a>
                                        <button data-id="<?php echo e($user->id); ?>" data-toggle="modal" data-target="#delete-user" class="red-bc custom-btn detachUser">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="project-map">
                        <input type="hidden" value="<?php echo e($singleProject->address); ?>" id="Location" class="geocomplete"  ><br>
                        <div class="map_canvas"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyAABrilV0K0SLv21ZVMv8Inz5YMI4YAKbI&amp;libraries=places"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.geocomplete.min.js')); ?>"></script>

    <script>
        $(function(){

            $(".geocomplete").geocomplete({
                map: ".map_canvas",
                location: $('#Location').val()
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>